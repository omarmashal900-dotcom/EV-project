-- ============================================================
-- Electric Vehicle Population Analysis  |  SQL Server (T-SQL)
-- Source: Electric Vehicle Population Data (Data.gov)
-- Table : [dbo].[ele vech]  (285,822 rows)
--
-- NOTE: Reconstructed from the SQL screenshots in the project
-- presentation. Statements are grouped by analysis step.
-- ============================================================


-- ------------------------------------------------------------
-- 1. DATA QUALITY: detect and fix missing / inconsistent values
-- ------------------------------------------------------------

-- Find rows with missing key fields
SELECT *
FROM [dbo].[ele vech]
WHERE City IS NULL
   OR Make IS NULL
   OR Model_Year IS NULL;

-- Replace NULLs with 'Unknown' so visuals do not drop these rows
UPDATE [dbo].[ele vech]
SET City = ISNULL(City, 'Unknown'),
    Make = ISNULL(Make, 'Unknown');

-- Standardize text (example: 'Tesla' / ' tesla ' -> 'TESLA')
UPDATE [dbo].[ele vech]
SET Make = UPPER(TRIM(Make));


-- ------------------------------------------------------------
-- 2. MARKET SIZE AND LEADERS
-- ------------------------------------------------------------

-- Total number of vehicles (result: 285,822)
SELECT COUNT(*) AS Total_Vehicles
FROM [dbo].[ele vech];

-- Top 5 brands by number of vehicles
-- (TESLA 117,392 | CHEVROLET 19,677 | NISSAN 16,121 | FORD 15,639 | KIA 14,328)
SELECT TOP 5 Make, COUNT(*) AS Total
FROM [dbo].[ele vech]
GROUP BY Make
ORDER BY Total DESC;

-- List of unique brands
SELECT DISTINCT Make
FROM [dbo].[ele vech];

-- Brands starting with a specific letter
SELECT DISTINCT Make
FROM [dbo].[ele vech]
WHERE Make LIKE 'B%';


-- ------------------------------------------------------------
-- 3. VEHICLE TYPE: BEV vs PHEV
-- ------------------------------------------------------------

-- (BEV 229,876 | PHEV 55,946)
SELECT Electric_Vehicle_Type, COUNT(*) AS Total
FROM [dbo].[ele vech]
GROUP BY Electric_Vehicle_Type;


-- ------------------------------------------------------------
-- 4. RANGE AND TECHNOLOGY TRENDS
-- ------------------------------------------------------------

-- Average electric range by model year
SELECT Model_Year, AVG(Electric_Range) AS Average_Range
FROM [dbo].[ele vech]
GROUP BY Model_Year
ORDER BY Model_Year DESC;

-- High-range vehicles (> 300 miles)
SELECT Make, Model, Electric_Range
FROM [dbo].[ele vech]
WHERE Electric_Range > 300;

-- Short-range vehicles (0-50 miles)
-- (condition partly hidden in the original screenshot)
SELECT Make, Model, Electric_Range
FROM [dbo].[ele vech]
WHERE Electric_Range < 50 AND Electric_Range > 0;


-- ------------------------------------------------------------
-- 5. BRAND DEEP DIVE AND GEOGRAPHY
-- ------------------------------------------------------------

-- Isolate Tesla records
SELECT Make, Model, Model_Year
FROM [dbo].[ele vech]
WHERE Make = 'TESLA';

-- Newest to oldest
SELECT Make, Model, Model_Year
FROM [dbo].[ele vech]
ORDER BY Model_Year DESC;

-- Vehicle locations by city
SELECT Make, Model, City
FROM [dbo].[ele vech];
